import React from "react";
import {AbsoluteFill, Audio, Composition, Sequence, interpolate, staticFile} from "remotion";
import {
  DURATION_IN_FRAMES,
  FPS,
  HEIGHT,
  OVERLAP,
  SCENES,
  SFX_CUES,
  SFX_LENGTH,
  WIDTH,
} from "./timeline";
import {SceneMystery} from "./scenes/Scene1Mystery";
import {SceneHistory} from "./scenes/Scene2History";
import {SceneDecision} from "./scenes/Scene3Decision";
import {SceneRequirements} from "./scenes/Scene4Requirements";
import {SceneFailed} from "./scenes/Scene5Failed";
import {SceneReveal} from "./scenes/Scene6Reveal";
import {C} from "./components/common";

const ORDER = [
  ["mystery", SceneMystery],
  ["history", SceneHistory],
  ["decision", SceneDecision],
  ["requirements", SceneRequirements],
  ["failed", SceneFailed],
  ["reveal", SceneReveal],
] as const;

/**
 * Scenes are stacked, each one fading in over the tail of the previous one.
 * The previous Sequence is extended by OVERLAP frames so there is never a
 * black dip between scenes.  NOTE: the only <Audio> tags are narration,
 * music and sfx.  There is no caption / subtitle layer anywhere.
 */
export const PlutoShort: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: C.bg}}>
      {ORDER.map(([key, Comp], i) => {
        const s = SCENES[key];
        const extra = i < ORDER.length - 1 ? OVERLAP : 0;
        return (
          <Sequence key={key} from={s.from} durationInFrames={s.duration + extra} name={key}>
            <Comp />
          </Sequence>
        );
      })}

      {/* Voice-over: standalone track, untouched */}
      <Audio src={staticFile("audio/narration.mp3")} volume={1} />

      {/* Ambient score, kept well under the voice */}
      <Audio
        src={staticFile("audio/music.mp3")}
        volume={(f) =>
          interpolate(f, [0, 60, DURATION_IN_FRAMES - 100, DURATION_IN_FRAMES], [0, 0.2, 0.2, 0], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          })
        }
      />

      {/* Whooshes / impacts / pings */}
      {SFX_CUES.map((c, i) => (
        <Sequence key={i} from={c.frame} durationInFrames={SFX_LENGTH[c.file]} name={`sfx-${c.file}`}>
          <Audio src={staticFile(`audio/${c.file}.wav`)} volume={c.volume} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="PlutoShort"
    component={PlutoShort}
    durationInFrames={DURATION_IN_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
