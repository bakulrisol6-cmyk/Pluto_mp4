import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {
  C,
  Dust,
  FONT_MONO,
  FONT_TITLE,
  Nebula,
  PlutoBall,
  RevealText,
  SceneFade,
  Starfield,
  Vignette,
  easeIO,
  lerp,
  prog,
} from "../components/common";

const CX = 540;
const CY = 930;
const RINGS = [
  {r: 130, label: "PLANET", color: "#9db8e8"},
  {r: 230, label: "DWARF PLANET", color: C.ice},
  {r: 330, label: "SMALL BODIES", color: "#9db8e8"},
];

const NODES = [
  {x: 140, year: "1930", cap: "PLUTO FOUND", at: 22},
  {x: 540, year: "2005", cap: "ERIS FOUND", at: 54},
  {x: 940, year: "2006", cap: "IAU DECIDES", at: 88},
];

/** SCENE 3 — THE 2006 DECISION: classification rings, Pluto reclassified, timeline. */
export const SceneDecision: React.FC = () => {
  const frame = useCurrentFrame();

  // Pluto travels from the PLANET ring to the DWARF PLANET ring
  const move = prog(frame, 80, 36, easeIO);
  const ringR = lerp(RINGS[0].r, RINGS[1].r, move);
  const ang = -0.35 + frame * 0.004;
  const px = CX + ringR * Math.cos(ang);
  const py = CY + ringR * Math.sin(ang);
  const arrived = prog(frame, 112, 14);
  const flash = Math.max(0, 1 - Math.abs(frame - 114) / 14);
  const plutoIn = prog(frame, 20, 22);

  const scanY = ((frame * 9) % 2200) - 150;
  const lineEnd = 140 + (940 - 140) * prog(frame, 20, 76, easeIO);

  return (
    <SceneFade>
      <AbsoluteFill>
        <Nebula blobs={[{x: 540, y: 930, r: 650, color: "rgba(40,90,190,0.30)", o: 0.6}]} />
        <Starfield seed="s3" count={150} drift={0.12} opacity={0.7} />
        <Dust seed="s3" count={16} opacity={0.3} />

        {/* HUD grid + scan line */}
        <svg width={1080} height={1920} style={{position: "absolute", left: 0, top: 0}}>
          {Array.from({length: 13}, (_, i) => (
            <line key={`v${i}`} x1={i * 90} y1={0} x2={i * 90} y2={1920} stroke="#6f9bff" strokeOpacity={0.06} />
          ))}
          {Array.from({length: 22}, (_, i) => (
            <line key={`h${i}`} x1={0} y1={i * 90} x2={1080} y2={i * 90} stroke="#6f9bff" strokeOpacity={0.06} />
          ))}
          <rect x={0} y={scanY} width={1080} height={120} fill="url(#scan)" />
          <defs>
            <linearGradient id="scan" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#8fdcff" stopOpacity="0" />
              <stop offset="0.7" stopColor="#8fdcff" stopOpacity="0.09" />
              <stop offset="1" stopColor="#8fdcff" stopOpacity="0" />
            </linearGradient>
          </defs>

          {/* classification rings */}
          {RINGS.map((rg, i) => {
            const p = prog(frame, 6 + i * 8, 28);
            const lit = i === 1 ? arrived : 0;
            return (
              <g key={rg.label} transform={`rotate(${frame * (i % 2 ? -0.18 : 0.22)} ${CX} ${CY})`} opacity={p}>
                <circle
                  cx={CX}
                  cy={CY}
                  r={rg.r}
                  fill="none"
                  stroke={rg.color}
                  strokeOpacity={0.45 + 0.4 * lit}
                  strokeWidth={2 + 2 * lit}
                  strokeDasharray="3 11"
                />
                <circle cx={CX} cy={CY} r={rg.r} fill="none" stroke={rg.color} strokeOpacity={0.12 + 0.2 * lit} strokeWidth={1} />
              </g>
            );
          })}
          <circle cx={CX} cy={CY} r={RINGS[1].r} fill="none" stroke={C.ice} strokeWidth={5} opacity={flash * 0.9} />
        </svg>

        <div
          style={{
            position: "absolute",
            left: CX - 90,
            top: CY - 40,
            width: 180,
            textAlign: "center",
            fontFamily: FONT_MONO,
            fontWeight: 700,
            fontSize: 54,
            letterSpacing: "0.16em",
            color: C.ice,
            opacity: 0.55 * prog(frame, 10, 24),
            textShadow: `0 0 24px ${C.ice}`,
          }}
        >
          IAU
        </div>

        {/* ring labels */}
        {RINGS.map((rg, i) => {
          const p = prog(frame, 22 + i * 8, 20);
          const active = i === 1 ? arrived : i === 0 ? 1 - move * 0.7 : 0.7;
          return (
            <div
              key={`l${rg.label}`}
              style={{
                position: "absolute",
                left: CX - 150,
                top: CY - rg.r - 20,
                width: 300,
                display: "flex",
                justifyContent: "center",
                opacity: p,
              }}
            >
              <div
                style={{
                  padding: "6px 18px",
                  borderRadius: 40,
                  background: "rgba(2,6,20,0.88)",
                  border: `1.5px solid ${rg.color}`,
                  fontFamily: FONT_MONO,
                  fontSize: 21,
                  letterSpacing: "0.18em",
                  color: rg.color,
                  opacity: 0.45 + 0.55 * active,
                  boxShadow: i === 1 ? `0 0 ${24 * arrived}px ${C.ice}` : "none",
                  whiteSpace: "nowrap",
                }}
              >
                {rg.label}
              </div>
            </div>
          );
        })}

        {/* Pluto, reclassified */}
        <div
          style={{
            position: "absolute",
            left: px - 38,
            top: py - 38,
            opacity: plutoIn,
            transform: `scale(${lerp(0.4, 1, plutoIn) * (1 + flash * 0.25)})`,
            filter: `drop-shadow(0 0 ${12 + flash * 30}px ${C.ice})`,
          }}
        >
          <PlutoBall size={76} haze={0.6} />
        </div>

        {/* Title */}
        <RevealText lines={["2006"]} start={6} size={168} top={150} tracking={0.08} />
        <div
          style={{
            position: "absolute",
            top: 372,
            left: 0,
            right: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 22,
            opacity: prog(frame, 22, 20),
          }}
        >
          <div style={{width: 70 * prog(frame, 22, 30), height: 2, background: C.ice, boxShadow: `0 0 10px ${C.ice}`}} />
          <div style={{fontFamily: FONT_TITLE, fontWeight: 700, fontSize: 52, letterSpacing: "0.14em", color: C.white, textShadow: `0 0 24px ${C.ice}55`}}>
            A NEW DEFINITION
          </div>
          <div style={{width: 70 * prog(frame, 22, 30), height: 2, background: C.ice, boxShadow: `0 0 10px ${C.ice}`}} />
        </div>

        {/* IAU decision as a timeline event */}
        <svg width={1080} height={1920} style={{position: "absolute", left: 0, top: 0}}>
          <line x1={140} y1={1400} x2={940} y2={1400} stroke="#6f9bff" strokeOpacity={0.25} strokeWidth={3} />
          <line x1={140} y1={1400} x2={lineEnd} y2={1400} stroke={C.ice} strokeWidth={3} style={{filter: `drop-shadow(0 0 8px ${C.ice})`}} />
          {NODES.map((n, i) => {
            const p = prog(frame, n.at, 16);
            const last = i === NODES.length - 1;
            const pulse = last ? 0.5 + 0.5 * Math.sin(frame * 0.2) : 0;
            return (
              <g key={n.year} opacity={p}>
                {last ? <circle cx={n.x} cy={1400} r={20 + pulse * 12} fill={C.warm} opacity={0.25} /> : null}
                <circle cx={n.x} cy={1400} r={last ? 13 : 9} fill={last ? C.warm : C.ice} />
              </g>
            );
          })}
        </svg>
        {NODES.map((n, i) => {
          const p = prog(frame, n.at, 20);
          const last = i === NODES.length - 1;
          const col = last ? C.warm : C.ice;
          return (
            <div
              key={`t${n.year}`}
              style={{
                position: "absolute",
                left: n.x - 140,
                top: 1318,
                width: 280,
                textAlign: "center",
                opacity: p,
              }}
            >
              <div style={{fontFamily: FONT_TITLE, fontWeight: 800, fontSize: 44, color: col, textShadow: `0 0 20px ${col}77`}}>{n.year}</div>
              <div style={{position: "absolute", top: 108, left: 0, right: 0, fontFamily: FONT_MONO, fontSize: 21, letterSpacing: "0.14em", color: C.ice2, opacity: 0.85}}>
                {n.cap}
              </div>
            </div>
          );
        })}
        <Vignette />
      </AbsoluteFill>
    </SceneFade>
  );
};
