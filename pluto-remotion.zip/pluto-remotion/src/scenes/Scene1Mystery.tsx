import React from "react";
import {AbsoluteFill, Easing, useCurrentFrame} from "remotion";
import {SCENES} from "../timeline";
import {
  C,
  Dust,
  MonoLabel,
  Nebula,
  PlutoBall,
  RevealText,
  SceneFade,
  Starfield,
  Vignette,
  lerp,
  prog,
} from "../components/common";

/** SCENE 1 — THE MYSTERY: Pluto alone in the dark, slow push-in, title reveal. */
export const SceneMystery: React.FC = () => {
  const frame = useCurrentFrame();
  const len = SCENES.mystery.duration;
  const zoom = lerp(0.74, 1.14, prog(frame, 0, len, Easing.inOut(Easing.quad)));
  const float = Math.sin(frame / 38) * 9;
  const lineP = prog(frame, 52, 40);

  return (
    <SceneFade>
      <AbsoluteFill>
        <Nebula
          blobs={[
            {x: 200, y: 1250, r: 520, color: "rgba(255,120,60,0.30)", o: 0.5},
            {x: 900, y: 700, r: 460, color: "rgba(90,70,200,0.28)", o: 0.5},
          ]}
        />
        <Starfield seed="s1" count={260} drift={0.3} />
        <Dust seed="s1" count={30} opacity={0.5} />

        {/* Pluto, slow cinematic push-in */}
        <div
          style={{
            position: "absolute",
            left: 540 - 350,
            top: 1100 - 350,
            width: 700,
            height: 700,
            transform: `translateY(${float}px) scale(${zoom})`,
          }}
        >
          <PlutoBall size={700} />
        </div>

        {/* Foreground dust for parallax */}
        <div style={{position: "absolute", inset: 0, transform: `scale(${1 + zoom * 0.08})`}}>
          <Dust seed="s1-fg" count={10} opacity={0.35} speed={2.2} />
        </div>

        {/* Title */}
        <RevealText
          lines={["WHY IS PLUTO", "NO LONGER", "A PLANET?"]}
          start={14}
          size={92}
          top={190}
          accent={["PLANET"]}
          tracking={0.05}
        />
        <div
          style={{
            position: "absolute",
            top: 548,
            left: 540 - 190 * lineP,
            width: 380 * lineP,
            height: 2,
            background: `linear-gradient(90deg, rgba(143,220,255,0), ${C.ice}, rgba(143,220,255,0))`,
            boxShadow: `0 0 14px ${C.ice}`,
          }}
        />
        <MonoLabel text="OUTER SOLAR SYSTEM · 5.9 BILLION KM FROM THE SUN" top={574} start={92} size={22} />

        <Vignette />
      </AbsoluteFill>
    </SceneFade>
  );
};
