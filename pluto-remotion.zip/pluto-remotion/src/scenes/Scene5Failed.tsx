import React, {useMemo} from "react";
import {AbsoluteFill, Img, random, staticFile, useCurrentFrame} from "remotion";
import {C, Dust, FONT_MONO, GlobalFilters, RevealText, SceneFade, SphereDefs, Starfield, Vignette, easeIO, lerp, prog} from "../components/common";

type Kbo = {x: number; y: number; r: number; tint: string; vx: number; vy: number; o: number};

const TINTS = ["#dff3ff", "#bfe3ff", "#ffe3d0", "#d6c3ff", "#ffd0c0", "#ffffff"];
const PLUTO_ANGLE = -0.62;
const PLUTO_AU = 39.5;
const PX = PLUTO_AU * Math.cos(PLUTO_ANGLE);
const PY = PLUTO_AU * Math.sin(PLUTO_ANGLE);

const K_START = 140; // px per AU, close-up on Pluto
const K_END = 7.6; // px per AU, whole belt visible
const CY = 800; // screen y of the focus point

/** SCENE 5 — WHY PLUTO FAILED: crowded neighbourhood, then zoom out to the whole Kuiper Belt. */
export const SceneFailed: React.FC = () => {
  const frame = useCurrentFrame();

  const objects = useMemo<Kbo[]>(() => {
    const list: Kbo[] = [];
    // the belt itself (distances in AU from the Sun)
    for (let i = 0; i < 1300; i++) {
      const u = random(`b-u-${i}`);
      const a = random(`b-a-${i}`) * Math.PI * 2;
      let rr: number;
      if (u < 0.22) rr = 39.4 + (random(`b-g-${i}`) + random(`b-h-${i}`) - 1) * 2.4; // Plutinos
      else if (u < 0.78) rr = 41.8 + random(`b-c-${i}`) * 6.5; // classical belt
      else rr = 30.5 + random(`b-s-${i}`) * 25; // scattered
      list.push({
        x: rr * Math.cos(a),
        y: rr * Math.sin(a),
        r: 0.05 + random(`b-r-${i}`) ** 3 * 0.25,
        tint: TINTS[Math.floor(random(`b-t-${i}`) * TINTS.length)],
        vx: 0,
        vy: 0,
        o: 0.5 + random(`b-o-${i}`) * 0.5,
      });
    }
    // Pluto's close neighbours (so the close-up is clearly crowded)
    for (let i = 0; i < 150; i++) {
      list.push({
        x: PX + (random(`n-x-${i}`) - 0.5) * 17,
        y: PY + (random(`n-y-${i}`) - 0.5) * 27,
        r: 0.05 + random(`n-r-${i}`) ** 2.6 * 0.3,
        tint: TINTS[Math.floor(random(`n-t-${i}`) * TINTS.length)],
        vx: (random(`n-vx-${i}`) - 0.5) * 0.012,
        vy: (random(`n-vy-${i}`) - 0.5) * 0.012,
        o: 0.4 + random(`n-o-${i}`) * 0.4,
      });
    }
    return list;
  }, []);

  const p = prog(frame, 80, 220, easeIO);
  const k = Math.exp(lerp(Math.log(K_START), Math.log(K_END), p));
  const fx = lerp(PX, 0, p);
  const fy = lerp(PY, 0, p);
  const sx = 540 + (PX - fx) * k;
  const sy = CY + (PY - fy) * k;
  const plutoR = Math.exp(lerp(Math.log(165), Math.log(11), p));
  const pulse = 0.5 + 0.5 * Math.sin(frame * 0.14);
  const ringO = prog(frame, 200, 40);

  const scrim = prog(frame, 40, 30);
  const labelsO = prog(frame, 250, 30);

  return (
    <SceneFade>
      <AbsoluteFill>
        <div style={{position: "absolute", inset: 0, background: "radial-gradient(ellipse at 50% 45%, #0a1230 0%, #02030a 70%)"}} />
        <Starfield seed="s5" count={220} drift={0.08} />
        <Dust seed="s5" count={20} opacity={0.35} />

        <svg width={1080} height={1920} style={{position: "absolute", left: 0, top: 0}}>
          <SphereDefs />
          <GlobalFilters />
          <g transform={`translate(540 ${CY}) scale(${k}) translate(${-fx} ${-fy})`}>
            {/* soft glow of the belt region */}
            <circle cx={0} cy={0} r={40} fill="none" stroke="#7fb4ff" strokeOpacity={0.05 * p} strokeWidth={22} />
            {/* planetary orbits */}
            {[5.2, 9.6, 19.2, 30.1].map((a, i) => (
              <circle key={a} cx={0} cy={0} r={a} fill="none" stroke={i === 3 ? "#7fb4ff" : "#9db8e8"} strokeOpacity={(i === 3 ? 0.5 : 0.22) * p} strokeWidth={1.3} vectorEffect="non-scaling-stroke" />
            ))}
            <circle cx={0} cy={0} r={4} fill="#ffcf7a" opacity={p} />
            <circle cx={0} cy={0} r={22 / k + 2} fill="#ff9a3c" opacity={0.5 * p} filter="url(#blur8)" />
            {/* icy objects */}
            {objects.map((o, i) => {
              const x = o.x + o.vx * frame;
              const y = o.y + o.vy * frame;
              const rpx = Math.max(o.r * k, 1.1);
              const r = rpx / k;
              return (
                <g key={i}>
                  <circle cx={x} cy={y} r={r} fill={o.tint} opacity={o.o * (rpx > 16 ? 0.55 : 1)} filter={rpx > 16 ? "url(#blur3)" : undefined} />
                  {rpx > 5 ? <circle cx={x} cy={y} r={r} fill="url(#shade)" opacity={o.o} /> : null}
                </g>
              );
            })}
          </g>
        </svg>

        {/* Pluto (photo) sits among its icy neighbours */}
        <div
          style={{
            position: "absolute",
            left: sx - plutoR,
            top: sy - plutoR,
            width: plutoR * 2,
            height: plutoR * 2,
            borderRadius: "50%",
            overflow: "hidden",
            boxShadow: `0 0 ${plutoR * 0.3}px rgba(143,220,255,0.4)`,
          }}
        >
          <Img src={staticFile("images/pluto-disc.png")} style={{width: "100%", height: "100%"}} />
        </div>
        <div
          style={{
            position: "absolute",
            left: sx - 30 - pulse * 3,
            top: sy - 30 - pulse * 3,
            width: 60 + pulse * 6,
            height: 60 + pulse * 6,
            borderRadius: "50%",
            border: `2.5px solid ${C.ice}`,
            boxShadow: `0 0 20px ${C.ice}`,
            opacity: ringO,
          }}
        />
        <div style={{position: "absolute", left: sx - 100, top: sy + 40, width: 200, textAlign: "center", fontFamily: FONT_MONO, fontWeight: 700, fontSize: 24, letterSpacing: "0.3em", color: C.ice, textShadow: `0 0 12px ${C.ice}`, opacity: ringO}}>
          PLUTO
        </div>

        {/* region labels */}
        <div style={{position: "absolute", left: 0, right: 0, top: CY - 55 * K_END - 96, textAlign: "center", fontFamily: FONT_MONO, opacity: labelsO}}>
          <div style={{fontWeight: 700, fontSize: 30, letterSpacing: "0.26em", color: C.white, textShadow: `0 0 16px ${C.ice}`}}>THE KUIPER BELT</div>
          <div style={{fontSize: 21, letterSpacing: "0.2em", color: C.ice, marginTop: 8}}>30–50 AU FROM THE SUN</div>
        </div>
        <div style={{position: "absolute", left: 0, right: 0, top: CY - 30.1 * K_END + 22, textAlign: "center", fontFamily: FONT_MONO, fontSize: 19, letterSpacing: "0.2em", color: "#8fb2ff", opacity: labelsO}}>
          NEPTUNE'S ORBIT
        </div>

        {/* bottom scrim + headline */}
        <div style={{position: "absolute", left: 0, right: 0, top: 1180, bottom: 0, background: "linear-gradient(to top, rgba(2,3,10,0.92) 30%, rgba(2,3,10,0))", opacity: scrim}} />
        <RevealText lines={["PLUTO HAS NOT", "CLEARED ITS ORBIT"]} start={70} size={72} top={1290} accent={["NOT"]} accentColor={C.red} tracking={0.04} />
        <Vignette strength={0.6} />
      </AbsoluteFill>
    </SceneFade>
  );
};
