import React from "react";
import {AbsoluteFill, Easing, useCurrentFrame} from "remotion";
import {SCENES} from "../timeline";
import {C, Dust, MonoLabel, Nebula, PlutoBall, RevealText, SceneFade, Starfield, Vignette, lerp, prog} from "../components/common";

/** SCENE 6 — THE FINAL REVEAL: Pluto up close, dwarf-planet title, closing line, slow zoom-out into deep space. */
export const SceneReveal: React.FC = () => {
  const frame = useCurrentFrame();
  const len = SCENES.reveal.duration;

  const push = lerp(1, 1.08, prog(frame, 0, 205, Easing.inOut(Easing.quad)));
  const out = prog(frame, 205, 125, Easing.inOut(Easing.cubic));
  const scale = lerp(push, 0.07, out);
  const float = Math.sin(frame / 40) * 7 * (1 - out);
  const centerY = lerp(900, 930, out);
  const haloBreath = 0.85 + 0.15 * Math.sin(frame * 0.05);
  // stars stream outward as we pull back
  const starZoom = 1 + out * 0.55;

  return (
    <SceneFade fadeOutFrom={len - 26} fadeOutLen={24}>
      <AbsoluteFill>
        <Nebula
          blobs={[
            {x: 540, y: 900, r: 760, color: "rgba(70,110,230,0.34)", o: 0.7},
            {x: 120, y: 1500, r: 480, color: "rgba(255,120,70,0.20)", o: 0.5},
          ]}
        />
        <div style={{position: "absolute", inset: 0, transform: `scale(${starZoom})`, transformOrigin: "50% 47%"}}>
          <Starfield seed="s6" count={300} drift={0.1} />
        </div>
        <Dust seed="s6" count={26} opacity={0.4} />

        {/* soft blue light spilling from the atmosphere */}
        <div
          style={{
            position: "absolute",
            left: 540 - 520,
            top: centerY - 520,
            width: 1040,
            height: 1040,
            borderRadius: "50%",
            background: "radial-gradient(circle, rgba(110,170,255,0.30) 0%, rgba(80,130,255,0.10) 42%, rgba(0,0,0,0) 68%)",
            transform: `scale(${scale * haloBreath})`,
          }}
        />
        <div
          style={{
            position: "absolute",
            left: 540 - 330,
            top: centerY - 330 + float,
            width: 660,
            height: 660,
            transform: `scale(${scale})`,
          }}
        >
          <PlutoBall size={660} haze={1.15} shade={0.6} />
        </div>

        <RevealText lines={["PLUTO IS A", "DWARF PLANET"]} start={20} size={86} top={170} accent={["DWARF", "PLANET"]} tracking={0.05} />
        <MonoLabel text="NEW HORIZONS · 2015 FLYBY" top={410} start={60} size={22} />

        <div style={{position: "absolute", left: 0, right: 0, top: 1210, bottom: 0, background: "linear-gradient(to top, rgba(2,3,10,0.8) 35%, rgba(2,3,10,0))", opacity: prog(frame, 220, 30)}} />
        <RevealText
          lines={["SMALLER DOESN'T", "MEAN LESS", "INTERESTING."]}
          start={232}
          size={74}
          top={1230}
          accent={["INTERESTING"]}
          tracking={0.04}
        />
        <Vignette />
      </AbsoluteFill>
    </SceneFade>
  );
};
