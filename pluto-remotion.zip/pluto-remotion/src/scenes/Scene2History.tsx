import React from "react";
import {AbsoluteFill, Img, staticFile, useCurrentFrame} from "remotion";
import {SCENES} from "../timeline";
import {
  C,
  Dust,
  FONT_MONO,
  GlobalFilters,
  Nebula,
  RevealText,
  SceneFade,
  SphereDefs,
  Starfield,
  Vignette,
  easeIO,
  lerp,
  prog,
} from "../components/common";

type Body = {
  name: string;
  rx: number;
  r: number;
  fill: string; // css/svg fill (solid or gradient url)
  a0: number; // start angle
  w: number; // angular speed rad/frame
  ring?: boolean;
  glow?: string;
};

const CX = 540;
const CY = 900;
const TILT = 0.36;

const BODIES: Body[] = [
  {name: "Mercury", rx: 78, r: 6, fill: "#a9a398", a0: 0.8, w: 0.052},
  {name: "Venus", rx: 122, r: 10, fill: "#e6c58c", a0: 3.1, w: 0.034},
  {name: "Earth", rx: 168, r: 11, fill: "#3f86e6", a0: 5.2, w: 0.026, glow: "#5aa8ff"},
  {name: "Mars", rx: 212, r: 8, fill: "#c3593a", a0: 1.9, w: 0.02},
  {name: "Jupiter", rx: 270, r: 27, fill: "url(#jupBands)", a0: 4.4, w: 0.0115},
  {name: "Saturn", rx: 332, r: 22, fill: "#dcc590", a0: 2.5, w: 0.0082, ring: true},
  {name: "Uranus", rx: 393, r: 15, fill: "#8fdde3", a0: 0.3, w: 0.0057},
  {name: "Neptune", rx: 450, r: 15, fill: "#3d63e0", a0: 5.9, w: 0.0045},
];
const PLUTO_RX = 505;
const PLUTO_SIZE = 36;

/** SCENE 2 — PLUTO'S HISTORY: eight planets + Pluto glowing as the 9th, then dive into Pluto. */
export const SceneHistory: React.FC = () => {
  const frame = useCurrentFrame();
  const len = SCENES.history.duration;
  void len;

  // camera: hold wide, then dive into Pluto
  const p = prog(frame, 100, 190, easeIO);
  const k = Math.exp(lerp(0, Math.log(15), p));
  const pAng = 0.55 + frame * 0.0012;
  const plutoX = CX + PLUTO_RX * Math.cos(pAng);
  const plutoY = CY + PLUTO_RX * TILT * 1.0 * Math.sin(pAng);
  const fx = lerp(CX, plutoX, p);
  const fy = lerp(CY, plutoY, p);
  const sx = 540 + (plutoX - fx) * k;
  const sy = 960 + (plutoY - fy) * k;

  const pulse = 0.5 + 0.5 * Math.sin(frame * 0.14);
  const ringOpacity = prog(frame, 36, 20) * (1 - prog(frame, 100, 70));
  const plutoIn = prog(frame, 26, 22);

  return (
    <SceneFade>
      <AbsoluteFill>
        <Nebula blobs={[{x: 540, y: 900, r: 700, color: "rgba(60,80,170,0.22)", o: 0.6}]} />
        <Starfield seed="s2" count={230} drift={0.15} />
        <Dust seed="s2" count={22} opacity={0.35} />

        <svg width={1080} height={1920} style={{position: "absolute", left: 0, top: 0}}>
          <SphereDefs />
          <GlobalFilters />
          <defs>
            <linearGradient id="jupBands" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="#b88f6a" />
              <stop offset="0.2" stopColor="#e6d0ae" />
              <stop offset="0.36" stopColor="#a8754f" />
              <stop offset="0.55" stopColor="#e9d8bb" />
              <stop offset="0.72" stopColor="#b98a62" />
              <stop offset="1" stopColor="#d7bc98" />
            </linearGradient>
            <radialGradient id="sunGrad">
              <stop offset="0" stopColor="#fffbe8" />
              <stop offset="0.45" stopColor="#ffd37a" />
              <stop offset="1" stopColor="#ff8f3a" />
            </radialGradient>
          </defs>
          <g transform={`translate(540 960) scale(${k}) translate(${-fx} ${-fy})`}>
            {/* orbits */}
            {BODIES.map((b, i) => (
              <ellipse
                key={b.name}
                cx={CX}
                cy={CY}
                rx={b.rx}
                ry={b.rx * TILT}
                fill="none"
                stroke="#9db8e8"
                strokeOpacity={0.3 * prog(frame, i * 4, 18)}
                strokeWidth={1.2}
                vectorEffect="non-scaling-stroke"
              />
            ))}
            <ellipse
              cx={CX}
              cy={CY}
              rx={PLUTO_RX}
              ry={PLUTO_RX * TILT}
              fill="none"
              stroke={C.ice}
              strokeOpacity={0.55 * prog(frame, 30, 20)}
              strokeWidth={1.6}
              vectorEffect="non-scaling-stroke"
            />

            {/* Sun */}
            <circle cx={CX} cy={CY} r={110} fill="#ff9a3c" opacity={0.42} filter="url(#blur30)" />
            <circle cx={CX} cy={CY} r={36} fill="url(#sunGrad)" />

            {/* planets */}
            {BODIES.map((b, i) => {
              const a = b.a0 + frame * b.w * 0.8;
              const x = CX + b.rx * Math.cos(a);
              const y = CY + b.rx * TILT * Math.sin(a);
              const s = prog(frame, 6 + i * 5, 20);
              return (
                <g key={b.name} transform={`translate(${x} ${y}) scale(${s})`}>
                  {b.glow ? <circle r={b.r * 2.4} fill={b.glow} opacity={0.35} filter="url(#blur8)" /> : null}
                  {b.ring ? (
                    <ellipse rx={b.r * 2} ry={b.r * 0.6} fill="none" stroke="#d8c59c" strokeWidth={b.r * 0.22} transform="rotate(-18)" opacity={0.85} />
                  ) : null}
                  <circle r={b.r} fill={b.fill} />
                  <circle r={b.r} fill="url(#shade)" />
                </g>
              );
            })}

            {/* Pluto glow (the disc itself is an HTML <Img> overlay) */}
            <circle cx={plutoX} cy={plutoY} r={26} fill={C.ice} opacity={0.35 * ringOpacity} filter="url(#blur8)" />
          </g>
        </svg>

        {/* Pluto: real photo disc, positioned in screen space */}
        <div
          style={{
            position: "absolute",
            left: sx - (PLUTO_SIZE * k) / 2,
            top: sy - (PLUTO_SIZE * k) / 2,
            width: PLUTO_SIZE * k,
            height: PLUTO_SIZE * k,
            borderRadius: "50%",
            overflow: "hidden",
            opacity: plutoIn,
            boxShadow: `0 0 ${12 * k}px rgba(143,220,255,${0.35 * (1 - p)})`,
          }}
        >
          <Img src={staticFile("images/pluto-disc.png")} style={{width: "100%", height: "100%"}} />
        </div>
        {/* glowing outline around Pluto */}
        <div
          style={{
            position: "absolute",
            left: sx - 30 - pulse * 3,
            top: sy - 30 - pulse * 3,
            width: 60 + pulse * 6,
            height: 60 + pulse * 6,
            borderRadius: "50%",
            border: `2.5px solid ${C.ice}`,
            boxShadow: `0 0 22px ${C.ice}, inset 0 0 18px ${C.ice}88`,
            opacity: ringOpacity,
          }}
        />
        <div
          style={{
            position: "absolute",
            left: sx - 120,
            top: sy - 82,
            width: 240,
            textAlign: "center",
            fontFamily: FONT_MONO,
            fontWeight: 700,
            fontSize: 28,
            letterSpacing: "0.3em",
            color: C.ice,
            textShadow: `0 0 16px ${C.ice}`,
            opacity: ringOpacity,
          }}
        >
          PLUTO
        </div>

        <RevealText
          lines={["ONCE THE", "9TH PLANET"]}
          start={20}
          size={100}
          top={1250}
          accent={["9TH"]}
          accentColor={C.warm}
          tracking={0.05}
          fadeOutFrom={170}
          fadeOutLen={30}
        />
        <Vignette />
      </AbsoluteFill>
    </SceneFade>
  );
};
