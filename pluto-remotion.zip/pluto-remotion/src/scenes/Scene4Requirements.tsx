import React, {useMemo} from "react";
import {AbsoluteFill, random, Sequence, useCurrentFrame} from "remotion";
import {REQ} from "../timeline";
import {
  C,
  Dust,
  FONT_MONO,
  FONT_TITLE,
  GlobalFilters,
  MonoLabel,
  Nebula,
  PlutoBall,
  RevealText,
  SceneFade,
  SphereDefs,
  Starfield,
  Verdict,
  Vignette,
  easeIO,
  lerp,
  prog,
} from "../components/common";

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */
const Part: React.FC<{len: number; children: React.ReactNode}> = ({len, children}) => {
  const f = useCurrentFrame();
  const o = Math.min(prog(f, 0, 9, (t) => t), 1 - prog(f, len - 9, 9, (t) => t));
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};

/** The 01 / 02 / 03 tracker at the top. state: 0 = pending, 1 = active, 2 = pass, 3 = fail */
const Hud: React.FC<{frame: number}> = ({frame}) => {
  const idx = frame < REQ.req1 ? -1 : frame < REQ.req2 ? 0 : frame < REQ.req3 ? 1 : 2;
  const results = [
    frame >= REQ.req1 + 95 ? 2 : 0,
    frame >= REQ.req2 + 100 ? 2 : 0,
    frame >= REQ.req3 + 150 ? 3 : 0,
  ];
  const p = prog(frame, 6, 24);
  return (
    <div style={{position: "absolute", top: 170, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 24, opacity: p}}>
      {["01", "02", "03"].map((n, i) => {
        const active = idx === i;
        const res = results[i];
        const col = res === 2 ? C.green : res === 3 ? C.red : active ? C.ice : "#6f86a8";
        return (
          <div
            key={n}
            style={{
              width: 170,
              padding: "12px 0",
              textAlign: "center",
              borderRadius: 60,
              border: `2px solid ${col}`,
              background: active || res ? `${col}1f` : "rgba(2,6,20,0.5)",
              boxShadow: active || res ? `0 0 28px ${col}55` : "none",
              fontFamily: FONT_MONO,
              fontWeight: 700,
              fontSize: 30,
              letterSpacing: "0.14em",
              color: col,
            }}
          >
            {n}
            {res === 2 ? " ✓" : res === 3 ? " ✕" : ""}
          </div>
        );
      })}
    </div>
  );
};

/* ------------------------------------------------------------------ */
/* intro                                                               */
/* ------------------------------------------------------------------ */
const Intro: React.FC = () => {
  const f = useCurrentFrame();
  const p = prog(f, 4, 30);
  return (
    <AbsoluteFill>
      <MonoLabel text="TO COUNT AS A PLANET" top={560} start={4} size={28} />
      <div
        style={{
          position: "absolute",
          top: 600,
          left: 0,
          right: 0,
          textAlign: "center",
          fontFamily: FONT_TITLE,
          fontWeight: 800,
          fontSize: 440,
          lineHeight: 1,
          color: C.white,
          opacity: p,
          transform: `scale(${lerp(1.25, 1, p)})`,
          filter: `blur(${(1 - p) * 20}px)`,
          textShadow: `0 0 60px ${C.ice}88, 0 0 140px ${C.ice}44`,
        }}
      >
        3
      </div>
      <RevealText lines={["REQUIREMENTS"]} start={16} size={74} top={1090} tracking={0.1} weight={700} />
    </AbsoluteFill>
  );
};

/* ------------------------------------------------------------------ */
/* requirement 1 — orbit the Sun                                       */
/* ------------------------------------------------------------------ */
const Req1: React.FC = () => {
  const f = useCurrentFrame();
  const CX = 540;
  const CY = 760;
  const bodies = [
    {rx: 330, ry: 125, r: 30, w: 0.05, a0: 0.4, pluto: false},
    {rx: 440, ry: 190, r: 26, w: 0.026, a0: 3.4, pluto: true},
  ];
  const sunP = prog(f, 0, 24);
  const trailLen = 46;

  const place = (b: (typeof bodies)[number], t: number) => {
    const a = b.a0 + t * b.w;
    return {x: CX + b.rx * Math.cos(a), y: CY + b.ry * Math.sin(a), depth: Math.sin(a)};
  };

  const drawBody = (b: (typeof bodies)[number], behind: boolean, key: number) => {
    const pos = place(b, f);
    if ((pos.depth < 0) !== behind) return null;
    const scale = 1 + 0.18 * pos.depth;
    const size = b.r * 2 * scale;
    return (
      <div key={key}>
        {b.pluto ? (
          <div style={{position: "absolute", left: pos.x - size / 2, top: pos.y - size / 2}}>
            <PlutoBall size={size} haze={0.5} />
          </div>
        ) : (
          <div
            style={{
              position: "absolute",
              left: pos.x - size / 2,
              top: pos.y - size / 2,
              width: size,
              height: size,
              borderRadius: "50%",
              background: "radial-gradient(circle at 32% 30%, #bfe3ff 0%, #3f86e6 38%, #12306a 80%, #060d20 100%)",
              boxShadow: "0 0 36px rgba(90,168,255,0.55)",
            }}
          />
        )}
      </div>
    );
  };

  return (
    <AbsoluteFill>
      <svg width={1080} height={1920} style={{position: "absolute", left: 0, top: 0}}>
        <GlobalFilters />
        <defs>
          <radialGradient id="sun1">
            <stop offset="0" stopColor="#fffbe8" />
            <stop offset="0.5" stopColor="#ffd37a" />
            <stop offset="1" stopColor="#ff8f3a" />
          </radialGradient>
        </defs>
        {bodies.map((b, i) => (
          <ellipse key={i} cx={CX} cy={CY} rx={b.rx} ry={b.ry} fill="none" stroke={b.pluto ? C.ice : "#9db8e8"} strokeOpacity={0.35 * prog(f, 4 + i * 8, 24)} strokeWidth={1.6} />
        ))}
        {/* comet-like trails */}
        {bodies.map((b, bi) =>
          Array.from({length: trailLen}, (_, i) => {
            const t = f - i * 1.6;
            const pos = place(b, t);
            const o = (1 - i / trailLen) * 0.5 * prog(f, 10, 20);
            return <circle key={`${bi}-${i}`} cx={pos.x} cy={pos.y} r={(b.pluto ? 5 : 7) * (1 - i / trailLen)} fill={b.pluto ? C.ice : "#7fb8ff"} opacity={o} />;
          }),
        )}
      </svg>

      {/* bodies behind the sun, sun, bodies in front */}
      {bodies.map((b, i) => drawBody(b, true, i))}
      <svg width={1080} height={1920} style={{position: "absolute", left: 0, top: 0}}>
        <GlobalFilters />
        <circle cx={CX} cy={CY} r={150} fill="#ff9a3c" opacity={0.5 * sunP} filter="url(#blur30)" />
        <circle cx={CX} cy={CY} r={70 * sunP} fill="url(#sun1)" />
      </svg>
      {bodies.map((b, i) => drawBody(b, false, i))}

      <MonoLabel text="REQUIREMENT 01" top={1230} start={4} size={24} />
      <RevealText lines={["ORBIT THE SUN"]} start={6} size={78} top={1272} tracking={0.05} />
      <Verdict start={95} ok label="PLUTO" top={1430} />
    </AbsoluteFill>
  );
};

/* ------------------------------------------------------------------ */
/* requirement 2 — be nearly round                                     */
/* ------------------------------------------------------------------ */
const Req2: React.FC = () => {
  const f = useCurrentFrame();
  const CX = 540;
  const CY = 760;
  const R = 200;
  const m = prog(f, 14, 66, easeIO);
  const amp = 0.36 * (1 - m);

  const pts: string[] = [];
  const N = 120;
  for (let i = 0; i < N; i++) {
    const t = (i / N) * Math.PI * 2;
    const wob =
      0.5 * Math.sin(3 * t + 1.0) + 0.35 * Math.sin(5 * t + 2.3) + 0.28 * Math.sin(7 * t + 0.4) + 0.22 * Math.sin(2 * t + 4.0);
    const rr = R * (1 + amp * wob);
    pts.push(`${i === 0 ? "M" : "L"}${(CX + rr * Math.cos(t)).toFixed(1)},${(CY + rr * Math.sin(t)).toFixed(1)}`);
  }
  const d = pts.join(" ") + " Z";

  const swap = prog(f, 66, 22, (t) => t);
  const gravity = prog(f, 10, 16) * (1 - prog(f, 70, 18));
  const phase = (f * 0.022) % 1;
  const dist = R * 1.28 + 90 * (1 - phase);

  return (
    <AbsoluteFill>
      <svg width={1080} height={1920} style={{position: "absolute", left: 0, top: 0}}>
        <GlobalFilters />
        <defs>
          <radialGradient id="rock" cx="36%" cy="32%" r="80%">
            <stop offset="0" stopColor="#9a9da8" />
            <stop offset="0.55" stopColor="#555964" />
            <stop offset="1" stopColor="#15171d" />
          </radialGradient>
        </defs>
        {/* gravity field */}
        {[1, 2, 3].map((i) => (
          <circle key={i} cx={CX} cy={CY} r={R * (1.3 + 0.28 * i) - 40 * phase} fill="none" stroke={C.ice} strokeOpacity={0.14 * gravity * (1 - phase * 0.6)} strokeWidth={1.5} />
        ))}
        {/* gravity arrows */}
        {Array.from({length: 12}, (_, i) => (
          <g key={i} transform={`translate(${CX} ${CY}) rotate(${i * 30}) translate(0 ${-dist})`} opacity={gravity * (0.35 + 0.65 * (1 - phase))}>
            <polygon points="0,26 -13,-6 13,-6" fill={C.ice} />
            <line x1={0} y1={-6} x2={0} y2={-36} stroke={C.ice} strokeWidth={4} strokeLinecap="round" />
          </g>
        ))}
        <ellipse cx={CX} cy={CY} rx={R * 1.1} ry={R * 1.1} fill={C.ice} opacity={0.12 * swap} filter="url(#blur30)" />
        <path d={d} fill="url(#rock)" stroke="#aeb4c2" strokeOpacity={0.5} strokeWidth={2} opacity={1 - swap} />
      </svg>
      <div style={{position: "absolute", left: CX - R, top: CY - R, opacity: swap}}>
        <PlutoBall size={R * 2} />
      </div>

      <MonoLabel text="REQUIREMENT 02" top={1230} start={4} size={24} />
      <RevealText lines={["BE NEARLY ROUND"]} start={6} size={74} top={1272} tracking={0.04} />
      <Verdict start={100} ok label="PLUTO" top={1430} />
    </AbsoluteFill>
  );
};

/* ------------------------------------------------------------------ */
/* requirement 3 — clear its orbit                                     */
/* ------------------------------------------------------------------ */
const Panel: React.FC<{
  cy: number;
  cleared: boolean;
  label: string;
  tag: string;
  tagColor: string;
  tagAt: number;
}> = ({cy, cleared, label, tag, tagColor, tagAt}) => {
  const f = useCurrentFrame();
  const CX = 540;
  const RX = 410;
  const RY = 105;
  const T0 = 28;
  const debris = useMemo(
    () =>
      Array.from({length: 48}, (_, i) => ({
        th: random(`d-${i}`) * Math.PI * 2,
        jr: (random(`j-${i}`) - 0.5) * 22,
        r: 2.4 + random(`r-${i}`) ** 2 * 5.5,
        tint: random(`t-${i}`) > 0.75 ? "#ffd7c2" : "#dff3ff",
      })),
    [],
  );

  const w = cleared ? 0.048 : 0.028;
  const th0 = Math.PI * 0.5;
  const sweep = w * Math.max(0, f - T0);
  const planetA = th0 + sweep;
  const pos = (th: number, jr = 0) => ({x: CX + (RX + jr) * Math.cos(th), y: cy + (RY + jr * 0.3) * Math.sin(th)});
  const planetPos = pos(planetA);
  const planetSize = cleared ? 84 : 54;

  const laneClear = cleared ? prog(f, T0 + (Math.PI * 2) / w - 10, 24) : 0;
  const appear = prog(f, 2, 22);

  return (
    <>
      <svg width={1080} height={1920} style={{position: "absolute", left: 0, top: 0}} opacity={appear}>
        <GlobalFilters />
        <ellipse cx={CX} cy={cy} rx={RX} ry={RY} fill="none" stroke={cleared ? C.green : C.red} strokeOpacity={0.08 + 0.34 * laneClear + (cleared ? 0 : 0.12 * prog(f, 150, 20))} strokeWidth={14} filter="url(#blur3)" />
        <ellipse cx={CX} cy={cy} rx={RX} ry={RY} fill="none" stroke="#9db8e8" strokeOpacity={0.4} strokeWidth={1.4} />
        {debris.map((b, i) => {
          const th = b.th + (cleared ? 0 : f * 0.0016);
          const p0 = pos(th, b.jr);
          if (!cleared) {
            return <circle key={i} cx={p0.x} cy={p0.y} r={b.r} fill={b.tint} opacity={0.85} />;
          }
          const delta = (((b.th - th0) % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2);
          const tCap = T0 + delta / w;
          const q = prog(f, tCap - 4, 16, (t) => t * t);
          const x = lerp(p0.x, planetPos.x, q);
          const y = lerp(p0.y, planetPos.y, q);
          return <circle key={i} cx={x} cy={y} r={b.r * (1 - 0.7 * q)} fill={b.tint} opacity={0.85 * (1 - q)} />;
        })}
      </svg>
      {cleared ? (
        <div
          style={{
            position: "absolute",
            left: planetPos.x - planetSize / 2,
            top: planetPos.y - planetSize / 2,
            width: planetSize,
            height: planetSize,
            borderRadius: "50%",
            opacity: appear,
            background: "radial-gradient(circle at 32% 30%, #ffe3c4 0%, #d98a4e 38%, #6b3216 80%, #1a0b05 100%)",
            boxShadow: "0 0 44px rgba(255,170,100,0.5)",
          }}
        />
      ) : (
        <div style={{position: "absolute", left: planetPos.x - 20, top: planetPos.y - 20, opacity: appear}}>
          <PlutoBall size={40} haze={0.5} />
        </div>
      )}
      <MonoLabel text={label} top={cy - RY - 78} start={6} size={26} color={C.white} />
      <MonoLabel text={tag} top={cy + RY + 36} start={tagAt} size={22} color={tagColor} />
    </>
  );
};

const Req3: React.FC = () => (
  <AbsoluteFill>
    <Panel cy={560} cleared label="A PLANET" tag="LANE CLEARED" tagColor={C.green} tagAt={150} />
    <div style={{position: "absolute", top: 790, left: 120, right: 120, height: 1, background: "linear-gradient(90deg, rgba(143,220,255,0), rgba(143,220,255,0.45), rgba(143,220,255,0))"}} />
    <Panel cy={1005} cleared={false} label="PLUTO" tag="LANE SHARED" tagColor={C.red} tagAt={150} />

    <MonoLabel text="REQUIREMENT 03" top={1270} start={4} size={24} />
    <RevealText lines={["CLEAR ITS ORBIT"]} start={6} size={74} top={1312} tracking={0.04} />
    <Verdict start={150} ok={false} label="PLUTO" top={1450} />
  </AbsoluteFill>
);

/* ------------------------------------------------------------------ */
/* scene                                                               */
/* ------------------------------------------------------------------ */
export const SceneRequirements: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <SceneFade>
      <AbsoluteFill>
        <Nebula blobs={[{x: 540, y: 800, r: 700, color: "rgba(50,80,190,0.22)", o: 0.6}]} />
        <Starfield seed="s4" count={170} drift={0.14} opacity={0.8} />
        <Dust seed="s4" count={18} opacity={0.3} />
        <SphereDefs />
        <Hud frame={frame} />
        <Sequence from={0} durationInFrames={REQ.req1}>
          <Part len={REQ.req1}><Intro /></Part>
        </Sequence>
        <Sequence from={REQ.req1} durationInFrames={REQ.req2 - REQ.req1}>
          <Part len={REQ.req2 - REQ.req1}><Req1 /></Part>
        </Sequence>
        <Sequence from={REQ.req2} durationInFrames={REQ.req3 - REQ.req2}>
          <Part len={REQ.req3 - REQ.req2}><Req2 /></Part>
        </Sequence>
        <Sequence from={REQ.req3} durationInFrames={REQ.end - REQ.req3 + 14}>
          <Part len={REQ.end - REQ.req3 + 14}><Req3 /></Part>
        </Sequence>
        <Vignette />
      </AbsoluteFill>
    </SceneFade>
  );
};
