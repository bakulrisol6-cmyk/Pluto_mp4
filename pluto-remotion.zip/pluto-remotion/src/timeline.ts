/**
 * MASTER TIMELINE  (single source of truth for every scene + sound cue)
 *
 * The narration MP3 (public/audio/narration.mp3) is 66.816 s long, so the
 * composition is 67.0 s (2010 frames) rather than exactly 60 s: the voice-over
 * plays untouched and the picture ends ~0.2 s after the last word.
 *
 * Scene cut points were snapped to the ~1.2 s pauses between narration
 * sentences (found with ffmpeg silencedetect), so every scene change lands
 * on a breath in the voice-over.  There is NO subtitle / caption data here:
 * this file only holds timing numbers.
 *
 * To re-time a scene, change its start (seconds).  Everything else follows.
 */
export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

export const AUDIO_SECONDS = 66.816;
export const DURATION_IN_FRAMES = 2010; // 67.0 s @ 30 fps

const sec = (s: number) => Math.round(s * FPS);

/** Scene start times in seconds (scene N ends where scene N+1 starts). */
const STARTS = {
  mystery: 0,
  history: 9.1,
  decision: 18.9,
  requirements: 24.1,
  failed: 43.3,
  reveal: 55.75,
} as const;

type Key = keyof typeof STARTS;
const KEYS = Object.keys(STARTS) as Key[];

export const SCENES = KEYS.reduce((acc, key, i) => {
  const from = sec(STARTS[key]);
  const to = i + 1 < KEYS.length ? sec(STARTS[KEYS[i + 1]]) : DURATION_IN_FRAMES;
  acc[key] = {from, to, duration: to - from};
  return acc;
}, {} as Record<Key, {from: number; to: number; duration: number}>);

/** Each scene fades in over the tail of the previous one (frames). */
export const OVERLAP = 14;

/** Sub-timing inside Scene 4 (frames relative to the scene start). */
export const REQ = {
  req1: sec(27.3 - STARTS.requirements),
  req2: sec(32.25 - STARTS.requirements),
  req3: sec(36.6 - STARTS.requirements),
  end: SCENES.requirements.duration,
};

/** Sound-effect cues (global frames). Files live in public/audio. */
export type Sfx = {frame: number; file: "whoosh" | "impact" | "ping"; volume: number};
export const SFX_LENGTH = {whoosh: 46, impact: 75, ping: 56};

const S = SCENES;
export const SFX_CUES: Sfx[] = [
  {frame: 14, file: "impact", volume: 0.55}, // title reveal
  // scene transitions (whoosh swells ~0.5 s in, so it starts just before the cut)
  {frame: S.history.from - 16, file: "whoosh", volume: 0.5},
  {frame: S.decision.from - 16, file: "whoosh", volume: 0.5},
  {frame: S.requirements.from - 16, file: "whoosh", volume: 0.5},
  {frame: S.failed.from - 16, file: "whoosh", volume: 0.5},
  {frame: S.reveal.from - 16, file: "whoosh", volume: 0.5},
  // scene 2: zoom into Pluto + "9TH"
  {frame: S.history.from + 34, file: "impact", volume: 0.4},
  {frame: S.history.from + 112, file: "whoosh", volume: 0.4},
  // scene 3: 2006 reveal, Pluto reclassified
  {frame: S.decision.from + 14, file: "impact", volume: 0.5},
  {frame: S.decision.from + 82, file: "whoosh", volume: 0.3},
  // scene 4: requirement changes + verdicts
  {frame: S.requirements.from + REQ.req1 - 8, file: "whoosh", volume: 0.35},
  {frame: S.requirements.from + REQ.req1 + 95, file: "ping", volume: 0.5},
  {frame: S.requirements.from + REQ.req2 - 8, file: "whoosh", volume: 0.35},
  {frame: S.requirements.from + REQ.req2 + 100, file: "ping", volume: 0.5},
  {frame: S.requirements.from + REQ.req3 - 8, file: "whoosh", volume: 0.35},
  {frame: S.requirements.from + REQ.req3 + 150, file: "impact", volume: 0.6},
  // scene 5
  {frame: S.failed.from + 70, file: "impact", volume: 0.5},
  {frame: S.failed.from + 90, file: "whoosh", volume: 0.5},
  // scene 6
  {frame: S.reveal.from + 22, file: "impact", volume: 0.6},
  {frame: S.reveal.from + 232, file: "impact", volume: 0.4},
  {frame: S.reveal.from + 205, file: "whoosh", volume: 0.55},
];
