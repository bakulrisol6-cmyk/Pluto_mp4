import React, {useMemo} from "react";
import {Easing, Img, interpolate, random, staticFile, useCurrentFrame} from "remotion";
import {loadFont as loadTitleFont} from "@remotion/google-fonts/Montserrat";
import {loadFont as loadMonoFont} from "@remotion/google-fonts/SpaceMono";
import {HEIGHT, WIDTH} from "../timeline";

const title = loadTitleFont("normal", {weights: ["500", "700", "800"], subsets: ["latin"]});
const mono = loadMonoFont("normal", {weights: ["400", "700"], subsets: ["latin"]});
export const FONT_TITLE = title.fontFamily;
export const FONT_MONO = mono.fontFamily;

export const C = {
  bg: "#02030a",
  ice: "#8fdcff",
  ice2: "#d6f0ff",
  warm: "#ffa563",
  red: "#ff5468",
  green: "#6dffb0",
  white: "#f4f8ff",
};

/* ---------- animation helpers ---------- */
export const easeOut = Easing.bezier(0.16, 1, 0.3, 1);
export const easeIO = Easing.inOut(Easing.cubic);
export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;

export const prog = (
  frame: number,
  start: number,
  dur: number,
  easing: (t: number) => number = easeOut,
) =>
  interpolate(frame, [start, start + dur], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing,
  });

/* ---------- backdrop pieces ---------- */
export const Starfield: React.FC<{
  seed: string;
  count?: number;
  drift?: number;
  opacity?: number;
}> = ({seed, count = 240, drift = 0.25, opacity = 1}) => {
  const frame = useCurrentFrame();
  const stars = useMemo(
    () =>
      Array.from({length: count}, (_, i) => {
        const d = random(`${seed}-d-${i}`);
        return {
          x: random(`${seed}-x-${i}`) * WIDTH,
          y: random(`${seed}-y-${i}`) * HEIGHT,
          d,
          r: 0.6 + d * d * 1.9,
          hue: random(`${seed}-h-${i}`),
          ph: random(`${seed}-p-${i}`) * 6.28,
        };
      }),
    [seed, count],
  );
  return (
    <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
      {stars.map((s, i) => {
        const x = (((s.x - frame * drift * (0.2 + s.d)) % WIDTH) + WIDTH) % WIDTH;
        const tw = 0.7 + 0.3 * Math.sin(frame * 0.07 + s.ph);
        const fill = s.hue < 0.15 ? "#ffd9b0" : s.hue > 0.85 ? "#b8d4ff" : "#ffffff";
        const o = (0.22 + 0.78 * s.d) * tw * opacity;
        return (
          <g key={i}>
            {s.r > 2.1 ? <circle cx={x} cy={s.y} r={s.r * 3.2} fill={fill} opacity={o * 0.12} /> : null}
            <circle cx={x} cy={s.y} r={s.r} fill={fill} opacity={o} />
          </g>
        );
      })}
    </svg>
  );
};

export const Dust: React.FC<{seed: string; count?: number; opacity?: number; speed?: number}> = ({
  seed,
  count = 34,
  opacity = 0.5,
  speed = 1,
}) => {
  const frame = useCurrentFrame();
  const parts = useMemo(
    () =>
      Array.from({length: count}, (_, i) => ({
        x: random(`${seed}-dx-${i}`) * WIDTH,
        y: random(`${seed}-dy-${i}`) * HEIGHT,
        r: 1.5 + random(`${seed}-dr-${i}`) * 5,
        vx: (random(`${seed}-dvx-${i}`) - 0.5) * 0.5,
        vy: -0.15 - random(`${seed}-dvy-${i}`) * 0.5,
        ph: random(`${seed}-dp-${i}`) * 6.28,
      })),
    [seed, count],
  );
  return (
    <svg width={WIDTH} height={HEIGHT} style={{position: "absolute", left: 0, top: 0}}>
      <defs>
        <radialGradient id={`dust-${seed}`}>
          <stop offset="0" stopColor="#cfe6ff" stopOpacity="0.9" />
          <stop offset="1" stopColor="#cfe6ff" stopOpacity="0" />
        </radialGradient>
      </defs>
      {parts.map((p, i) => {
        const x = (((p.x + frame * p.vx * speed + Math.sin(frame * 0.02 + p.ph) * 14) % WIDTH) + WIDTH) % WIDTH;
        const y = (((p.y + frame * p.vy * speed) % HEIGHT) + HEIGHT) % HEIGHT;
        const o = opacity * (0.4 + 0.6 * Math.abs(Math.sin(frame * 0.03 + p.ph)));
        return <circle key={i} cx={x} cy={y} r={p.r * 3} fill={`url(#dust-${seed})`} opacity={o} />;
      })}
    </svg>
  );
};

export const Nebula: React.FC<{
  blobs: {x: number; y: number; r: number; color: string; o: number}[];
}> = ({blobs}) => {
  const frame = useCurrentFrame();
  return (
    <>
      {blobs.map((b, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: b.x - b.r + Math.sin(frame * 0.006 + i) * 26,
            top: b.y - b.r + Math.cos(frame * 0.005 + i * 2) * 20,
            width: b.r * 2,
            height: b.r * 2,
            borderRadius: "50%",
            background: `radial-gradient(circle, ${b.color} 0%, rgba(0,0,0,0) 68%)`,
            opacity: b.o,
          }}
        />
      ))}
    </>
  );
};

export const Vignette: React.FC<{strength?: number}> = ({strength = 0.7}) => (
  <div
    style={{
      position: "absolute",
      inset: 0,
      background: `radial-gradient(ellipse at 50% 48%, rgba(0,0,0,0) 45%, rgba(0,0,0,${strength}) 100%)`,
      pointerEvents: "none",
    }}
  />
);

/** Fade-in (and optional fade-out) wrapper for every scene, with a soft push-in. */
export const SceneFade: React.FC<{
  children: React.ReactNode;
  fadeOutFrom?: number;
  fadeOutLen?: number;
  fadeInLen?: number;
}> = ({children, fadeOutFrom, fadeOutLen = 20, fadeInLen = 14}) => {
  const frame = useCurrentFrame();
  const inP = prog(frame, 0, fadeInLen, Easing.inOut(Easing.quad));
  const outP = fadeOutFrom === undefined ? 0 : prog(frame, fadeOutFrom, fadeOutLen, Easing.inOut(Easing.quad));
  const scale = lerp(1.05, 1, prog(frame, 0, 26));
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        backgroundColor: C.bg,
        opacity: inP * (1 - outP),
        transform: `scale(${scale})`,
        overflow: "hidden",
      }}
    >
      {children}
    </div>
  );
};

/* ---------- typography ---------- */
export const RevealText: React.FC<{
  lines: string[];
  start: number;
  size: number;
  top: number;
  accent?: string[];
  accentColor?: string;
  weight?: number;
  tracking?: number; // final letter-spacing in em
  lineHeight?: number;
  fadeOutFrom?: number;
  fadeOutLen?: number;
  color?: string;
}> = ({
  lines,
  start,
  size,
  top,
  accent = [],
  accentColor = C.ice,
  weight = 800,
  tracking = 0.05,
  lineHeight = 1.12,
  fadeOutFrom,
  fadeOutLen = 20,
  color = C.white,
}) => {
  const frame = useCurrentFrame();
  const out = fadeOutFrom === undefined ? 0 : prog(frame, fadeOutFrom, fadeOutLen, Easing.inOut(Easing.quad));
  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        top,
        textAlign: "center",
        fontFamily: FONT_TITLE,
        fontWeight: weight,
        fontSize: size,
        lineHeight,
        color,
        opacity: 1 - out,
        padding: "0 40px",
      }}
    >
      {lines.map((line, li) => (
        <div key={li} style={{whiteSpace: "nowrap"}}>
          {line.split(" ").map((word, wi) => {
            const p = prog(frame, start + li * 9 + wi * 5, 30);
            const isAccent = accent.includes(word.replace(/[?.!,']/g, ""));
            const col = isAccent ? accentColor : color;
            return (
              <span
                key={wi}
                style={{
                  display: "inline-block",
                  marginRight: "0.28em",
                  opacity: p,
                  transform: `translateY(${(1 - p) * 40}px)`,
                  filter: `blur(${(1 - p) * 18}px)`,
                  letterSpacing: `${lerp(0.4, tracking, p)}em`,
                  color: col,
                  textShadow: `0 0 28px ${col}66, 0 0 70px ${col}33, 0 4px 18px rgba(0,0,0,0.6)`,
                }}
              >
                {word}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};

/** Small mono visual label (never narration text). */
export const MonoLabel: React.FC<{
  text: string;
  top: number;
  start: number;
  size?: number;
  color?: string;
  left?: number;
  align?: "center" | "left";
  fadeOutFrom?: number;
}> = ({text, top, start, size = 26, color = C.ice, left, align = "center", fadeOutFrom}) => {
  const frame = useCurrentFrame();
  const p = prog(frame, start, 24);
  const out = fadeOutFrom === undefined ? 0 : prog(frame, fadeOutFrom, 16);
  return (
    <div
      style={{
        position: "absolute",
        top,
        left: left ?? 0,
        right: left === undefined ? 0 : undefined,
        textAlign: align,
        fontFamily: FONT_MONO,
        fontSize: size,
        letterSpacing: "0.22em",
        color,
        opacity: p * (1 - out),
        transform: `translateY(${(1 - p) * 14}px)`,
        textShadow: `0 0 14px ${color}77`,
        whiteSpace: "nowrap",
      }}
    >
      {text}
    </div>
  );
};

/** Verdict pill, e.g. "PLUTO ✓" */
export const Verdict: React.FC<{start: number; ok: boolean; label: string; top: number}> = ({
  start,
  ok,
  label,
  top,
}) => {
  const frame = useCurrentFrame();
  const p = prog(frame, start, 22);
  const col = ok ? C.green : C.red;
  return (
    <div
      style={{
        position: "absolute",
        top,
        left: 0,
        right: 0,
        display: "flex",
        justifyContent: "center",
        opacity: p,
        transform: `scale(${lerp(0.8, 1, p)})`,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 22,
          padding: "16px 40px",
          borderRadius: 100,
          border: `2px solid ${col}`,
          background: `${col}1c`,
          boxShadow: `0 0 40px ${col}44, inset 0 0 24px ${col}22`,
          fontFamily: FONT_MONO,
          fontWeight: 700,
          fontSize: 34,
          letterSpacing: "0.16em",
          color: col,
        }}
      >
        <span>{label}</span>
        <span style={{fontSize: 44, lineHeight: 1}}>{ok ? "✓" : "✕"}</span>
      </div>
    </div>
  );
};

/* ---------- Pluto (real photo cut-out with cinematic lighting) ---------- */
export const PlutoBall: React.FC<{size: number; haze?: number; shade?: number}> = ({
  size,
  haze = 1,
  shade = 0.55,
}) => (
  <div style={{position: "relative", width: size, height: size}}>
    {/* blue atmospheric haze */}
    <div
      style={{
        position: "absolute",
        inset: -size * 0.14,
        borderRadius: "50%",
        background:
          "radial-gradient(circle, rgba(120,190,255,0) 60%, rgba(120,190,255,0.20) 68%, rgba(90,150,255,0.07) 80%, rgba(90,150,255,0) 94%)",
        opacity: haze,
      }}
    />
    <div
      style={{
        position: "absolute",
        inset: 0,
        borderRadius: "50%",
        overflow: "hidden",
        boxShadow: `0 0 ${size * 0.08}px rgba(140,200,255,${0.3 * haze})`,
      }}
    >
      <Img src={staticFile("images/pluto-disc.png")} style={{width: "100%", height: "100%", display: "block"}} />
      <div
        style={{
          position: "absolute",
          inset: 0,
          background: `radial-gradient(circle at 30% 38%, rgba(0,0,0,0) 42%, rgba(0,2,14,${shade}) 90%)`,
        }}
      />
      {/* thin blue limb light */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: "50%",
          boxShadow: `inset 0 0 ${size * 0.05}px rgba(150,205,255,${0.45 * haze})`,
        }}
      />
    </div>
  </div>
);

/** Shared SVG gradients for shaded spheres. */
export const SphereDefs: React.FC = () => (
  <defs>
    <radialGradient id="shade" cx="34%" cy="34%" r="80%">
      <stop offset="0" stopColor="#000" stopOpacity="0" />
      <stop offset="0.55" stopColor="#000" stopOpacity="0.15" />
      <stop offset="1" stopColor="#000" stopOpacity="0.78" />
    </radialGradient>
    <radialGradient id="iceBall" cx="35%" cy="32%" r="75%">
      <stop offset="0" stopColor="#ffffff" />
      <stop offset="0.5" stopColor="#bcd8ee" />
      <stop offset="1" stopColor="#3b4f66" />
    </radialGradient>
  </defs>
);

export const GlobalFilters: React.FC = () => (
  <defs>
    <filter id="blur30" x="-100%" y="-100%" width="300%" height="300%">
      <feGaussianBlur stdDeviation="30" />
    </filter>
    <filter id="blur8" x="-100%" y="-100%" width="300%" height="300%">
      <feGaussianBlur stdDeviation="8" />
    </filter>
    <filter id="blur3" x="-100%" y="-100%" width="300%" height="300%">
      <feGaussianBlur stdDeviation="3" />
    </filter>
  </defs>
);
