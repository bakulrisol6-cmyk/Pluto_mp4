#!/usr/bin/env bash
# Synthesises the score + SFX with ffmpeg (no external downloads). Re-run to regenerate.
set -e
cd "$(dirname "$0")/../public/audio"
D=67
# Ambient pad: stacked A-minor-ish drones, slow tremolo, low-pass, reverb-ish echo, swell
ffmpeg -y -v error \
 -f lavfi -i "sine=f=55:d=$D" -f lavfi -i "sine=f=82.41:d=$D" -f lavfi -i "sine=f=110:d=$D" \
 -f lavfi -i "sine=f=164.81:d=$D" -f lavfi -i "sine=f=220.5:d=$D" -f lavfi -i "sine=f=329.6:d=$D" \
 -filter_complex "[0]volume=0.9[a];[1]tremolo=f=0.11:d=0.5,volume=0.6[b];[2]tremolo=f=0.1:d=0.6,volume=0.5[c];[3]tremolo=f=0.13:d=0.7,volume=0.3[d];[4]tremolo=f=0.12:d=0.8,volume=0.18[e];[5]tremolo=f=0.17:d=0.9,volume=0.08[f];[a][b][c][d][e][f]amix=inputs=6:normalize=0,lowpass=f=900,aecho=0.8:0.7:700|1300:0.35|0.25,volume=0.55,afade=t=in:d=3,afade=t=out:st=62:d=5,aformat=channel_layouts=stereo" \
 -c:a libmp3lame -b:a 192k music.mp3
# Whoosh: band-passed noise with swell envelope
ffmpeg -y -v error -f lavfi -i "anoisesrc=d=1.4:c=pink:a=0.8" \
 -af "highpass=f=250,lowpass=f=3500,tremolo=f=0.7:d=0.9,afade=t=in:d=0.6,afade=t=out:st=0.6:d=0.8,aecho=0.7:0.6:120:0.3,volume=0.8,aformat=channel_layouts=stereo" whoosh.wav
# Impact: pitch-dropping sub thump + short noise burst
ffmpeg -y -v error -f lavfi -i "aevalsrc='0.9*sin(2*PI*(42+90*exp(-t*9))*t)*exp(-t*2.6)':d=2.2:s=44100" \
 -f lavfi -i "anoisesrc=d=2.2:c=brown:a=0.5" \
 -filter_complex "[1]lowpass=f=600,afade=t=out:st=0:d=0.5[n];[0][n]amix=inputs=2:normalize=0,aecho=0.8:0.6:300:0.3,aformat=channel_layouts=stereo" impact.wav
# Soft ping for requirement reveals
ffmpeg -y -v error -f lavfi -i "aevalsrc='0.5*sin(2*PI*880*t)*exp(-t*3.5)+0.25*sin(2*PI*1320*t)*exp(-t*4)':d=1.6:s=44100" \
 -af "aecho=0.8:0.7:260:0.4,aformat=channel_layouts=stereo" ping.wav
ls -la
