// Cuts the Pluto disc out of the source photo -> public/images/pluto-disc.png (transparent bg)
const sharp = require("sharp");
const cx = 350, cy = 554, r = 270, S = 1080;
const mask = Buffer.from(`<svg width="${S}" height="${S}"><defs><radialGradient id="g"><stop offset="0.965" stop-color="#fff"/><stop offset="1" stop-color="#000"/></radialGradient></defs><circle cx="${S/2}" cy="${S/2}" r="${S/2}" fill="url(#g)"/></svg>`);
sharp("public/images/pluto-source.jpg")
  .extract({ left: cx - r, top: cy - r, width: 2 * r, height: 2 * r })
  .resize(S, S, { kernel: "lanczos3" })
  .ensureAlpha()
  .composite([{ input: mask, blend: "dest-in" }])
  .png().toFile("public/images/pluto-disc.png").then(() => console.log("ok"));
