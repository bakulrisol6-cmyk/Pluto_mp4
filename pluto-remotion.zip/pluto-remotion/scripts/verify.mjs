// Pre-render sanity check. Run: npm run verify
import {readFileSync, readdirSync, statSync} from "node:fs";
import {execFileSync} from "node:child_process";
import {join} from "node:path";

let bad = 0;
const ok = (m) => console.log("  ok   " + m);
const fail = (m) => { console.log("  FAIL " + m); bad++; };
const num = (src, name) => Number(new RegExp(`export const ${name}\\s*=\\s*([0-9.]+)`).exec(src)?.[1]);

const tl = readFileSync("src/timeline.ts", "utf8");
const FPS = num(tl, "FPS"), W = num(tl, "WIDTH"), H = num(tl, "HEIGHT"), D = num(tl, "DURATION_IN_FRAMES"), A = num(tl, "AUDIO_SECONDS");

console.log("Format");
FPS === 30 ? ok("30 fps") : fail("fps " + FPS);
W === 1080 && H === 1920 ? ok("1080x1920 (9:16)") : fail(`size ${W}x${H}`);
console.log(`Duration\n  ${D} frames = ${(D / FPS).toFixed(2)} s, narration = ${A.toFixed(3)} s`);
Math.abs(D / FPS - A) < 0.5 ? ok("video length within 0.5 s of narration") : fail("video/narration length mismatch");

const root = readFileSync("src/Root.tsx", "utf8");
/durationInFrames=\{DURATION_IN_FRAMES\}/.test(root) && /fps=\{FPS\}/.test(root) && /width=\{WIDTH\}/.test(root) && /height=\{HEIGHT\}/.test(root)
  ? ok("Composition uses the timeline constants") : fail("Composition not wired to timeline.ts");

try {
  const d = Number(execFileSync("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", "public/audio/narration.mp3"]).toString());
  Math.abs(d - A) < 0.05 ? ok(`narration.mp3 is ${d.toFixed(3)} s`) : fail(`narration.mp3 is ${d.toFixed(3)} s but AUDIO_SECONDS=${A}. Update src/timeline.ts`);
} catch { console.log("  skip ffprobe not found (audio length not checked)"); }

console.log("Scene timing");
const sc = {};
for (const m of tl.matchAll(/^\s{2}(\w+): ([0-9.]+),$/gm)) sc[m[1]] = Number(m[2]);
const keys = ["mystery", "history", "decision", "requirements", "failed", "reveal"];
let prev = -1;
for (const k of keys) { if (sc[k] === undefined || sc[k] <= prev) fail(`scene ${k} start ${sc[k]}`); prev = sc[k]; }
if (!bad) ok(keys.map((k) => `${k}@${sc[k]}s`).join("  "));
sc.reveal < D / FPS ? ok("last scene starts before the end") : fail("last scene starts after the end");

console.log("No subtitles / captions");
const banned = /subtitle|caption|\.srt|\.vtt|@remotion\/captions|word-by-word|transcript/i;
const walk = (dir) => readdirSync(dir).flatMap((f) => { const p = join(dir, f); return statSync(p).isDirectory() ? walk(p) : [p]; });
for (const f of walk("src")) {
  const lines = readFileSync(f, "utf8").split("\n");
  lines.forEach((l, i) => {
    // allow the explanatory "no subtitles" comments
    if (banned.test(l) && !/\bno\b.*(subtitle|caption)|not.*(subtitle|caption)/i.test(l)) fail(`${f}:${i + 1} ${l.trim()}`);
  });
}
if (!bad) ok("no subtitle/caption code or data in src/");

console.log(bad ? `\n${bad} problem(s)` : "\nAll checks passed");
process.exit(bad ? 1 : 0);
